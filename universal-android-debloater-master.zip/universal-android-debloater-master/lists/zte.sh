#!/usr/bin/env bash

# I NEVER HAD A ZTE DEVICE ON HAND. 
# I did some intensive searches on the web to find a list and I try my best to document it. But I need ZTE users to really improve it.
# I use [MORE INFO NEEDED] tag as a marker.

declare -a zte=(

	"com.zte.assistant"
	# ZTE Voice Assistant

	"com.zte.weather"
	# ZTE Weather app
	)
